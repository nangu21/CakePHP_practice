<?php
    class Post extends AppModel{
        public $validate = array( //DBと合わせる
            'title' => array(
                'rule' => 'notEmpty',
                'message' => '空じゃだめだよ'
            ),
            'body' => array(
                'rule' => 'notEmpty'
            )
        );
    }

?>